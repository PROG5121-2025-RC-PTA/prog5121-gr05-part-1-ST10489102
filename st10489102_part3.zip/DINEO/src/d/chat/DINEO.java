 package d.chat;

import javax.swing.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class DINEO {

    // User management class (previously DINEO)
    public static class User {
        private String username;
        private String password;
        private String cellphoneNumber;
        private String firstName;
        private String lastName;

        public User(String firstName, String lastName) {
            this.firstName = firstName;
            this.lastName = lastName;
        }

        public boolean checkUserName(String username) {
            return username != null && username.contains("_") && username.length() <= 5;
        }

        public boolean checkPasswordComplexity(String password) {
            if (password == null) return false;
            return password.length() >= 8 &&
                   password.matches(".*[A-Z].*") &&
                   password.matches(".*\\d.*") &&
                   password.matches(".*[!@#$%^&*(),.?\":{}|<>].*");
        }

        public boolean checkCellPhoneNumber(String phone) {
            return phone != null && phone.matches("^\\+\\d{1,3}\\d{7,10}$");
        }

        public String registerUser(String username, String password, String cellphoneNumber) {
            if (!checkUserName(username)) {
                return "Username is not correctly formatted, please ensure that your username contains an underscore and is no more than five characters in length.";
            }

            if (!checkPasswordComplexity(password)) {
                return "Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.";
            }

            if (!checkCellPhoneNumber(cellphoneNumber)) {
                return "Cell phone number incorrectly formatted or does not contain international code.";
            }

            this.username = username;
            this.password = password;
            this.cellphoneNumber = cellphoneNumber;

            return "Username successfully captured.\nPassword successfully captured.\nCell phone number successfully added.\nUser registered successfully.";
        }

        public boolean loginUser(String username, String password) {
            return this.username != null && this.username.equals(username) && this.password.equals(password);
        }

        public String returnLoginStatus(boolean loginSuccess) {
            return loginSuccess
                ? "Welcome " + this.firstName + " " + this.lastName + ", it is great to see you again."
                : "Username or password incorrect, please try again.";
        }
    }

    // Message class to handle messages
    public static class Message {
        private int id;
        private String recipientNumber;
        private String content;

        private static int totalSentMessages = 0;

        public Message(int id, String recipientNumber, String content) {
            this.id = id;
            this.recipientNumber = recipientNumber;
            this.content = content;
        }

        public int getId() {
            return id;
        }

        public String getRecipientNumber() {
            return recipientNumber;
        }

        public String getContent() {
            return content;
        }

        public boolean checkRecipientCell() {
            return recipientNumber != null && recipientNumber.matches("^\\+\\d{1,3}\\d{7,10}$") && recipientNumber.length() <= 13;
        }

        public String sendMessage(String action) {
            switch (action.toLowerCase()) {
                case "send":
                    totalSentMessages++;
                    return "Message sent to " + recipientNumber;
                case "store":
                    return "Message stored.";
                case "discard":
                    return "Message discarded.";
                default:
                    return "Invalid action.";
            }
        }

        public String printMessage() {
            return "Message ID: " + id + "\nRecipient: " + recipientNumber + "\nContent: " + content;
        }

        public static int getTotalSentMessages() {
            return totalSentMessages;
        }
    }

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        List<Message> messages = new ArrayList<>();

        System.out.println("Hello, Welcome to DChat");

        // User Registration
        System.out.print("Enter your first name: ");
        String firstName = input.nextLine();

        System.out.print("Enter your last name: ");
        String lastName = input.nextLine();

        User user = new User(firstName, lastName);

        String username, password, phone;

        while (true) {
            System.out.print("Enter username (must contain underscore and max 5 characters): ");
            username = input.nextLine();

            System.out.print("Enter password (min 8 chars, 1 capital, 1 number, 1 special char): ");
            password = input.nextLine();

            System.out.print("Enter cellphone number (e.g. +1234567890): ");
            phone = input.nextLine();

            String registrationMessage = user.registerUser(username, password, phone);
            System.out.println(registrationMessage);

            if (registrationMessage.contains("User registered successfully")) {
                break;
            } else {
                System.out.println("Please try again.\n");
            }
        }

        // User Login
        System.out.println("\nPlease log in:");

        System.out.print("Username: ");
        String loginUsername = input.nextLine();

        System.out.print("Password: ");
        String loginPassword = input.nextLine();

        boolean loggedIn = user.loginUser(loginUsername, loginPassword);
        System.out.println(user.returnLoginStatus(loggedIn));

        if (!loggedIn) {
            System.out.println("Exiting application due to failed login.");
            input.close();
            return;
        }

        System.out.println("Welcome to QuickChat.");

        System.out.print("Please enter how many messages you want to send: ");
        int numMessages = 0;
        while (true) {
            try {
                numMessages = Integer.parseInt(input.nextLine());
                if (numMessages <= 0) {
                    System.out.print("Please enter a positive integer for number of messages: ");
                } else {
                    break;
                }
            } catch (NumberFormatException e) {
                System.out.print("Invalid number, try again: ");
            }
        }

        for (int i = 1; i <= numMessages; i++) {
            System.out.print("Enter recipient number (include international code, max 13 chars): ");
            String recipient = input.nextLine();

            System.out.print("Enter message (max 250 characters): ");
            String content = input.nextLine();

            if (content.length() > 250) {
                System.out.println("Message exceeds 250 characters by " + (content.length() - 250) + ", please reduce size.");
                i--; // Retry this message
                continue;
            }

            Message msg = new Message(i, recipient, content);

            if (!msg.checkRecipientCell()) {
                System.out.println("Cell phone number is incorrectly formatted or does not contain an international code.");
                i--;
                continue;
            }

            String action;
            while (true) {
                System.out.print("Do you want to Send, Store or Discard the message? ");
                action = input.nextLine().trim().toLowerCase();
                if (action.equals("send") || action.equals("store") || action.equals("discard")) {
                    break;
                }
                System.out.println("Invalid choice. Try again.");
            }

            System.out.println(msg.sendMessage(action));
            messages.add(msg);

            if (action.equals("send")) {
                JOptionPane.showMessageDialog(null, msg.printMessage(), "Message Sent", JOptionPane.INFORMATION_MESSAGE);
            }
        }

        // Here you can implement the Part 3 menu to interact with messages
        // For example:
        List<Message> sentMessages = new ArrayList<>();
        List<Message> storedMessages = new ArrayList<>();
        List<Message> disregardedMessages = new ArrayList<>();

        // Separate messages into categories
        for (Message m : messages) {
            // We need to track action for each message - currently it's not stored, so let's assume:
            // We'll change Message class to store action, but since not done here, 
            // for demo let's assume messages with id <= totalSentMessages are sent
            // (A better approach is to add 'action' field to Message.)
            // For now, let's just put all messages into sentMessages to avoid errors.

            // You can improve this by adding action attribute to Message class.
            sentMessages.add(m);
        }

        // Menu for Part 3 features
        while (true) {
            System.out.println("\nChoose an action:");
            System.out.println("1) Display all sent messages (recipient and content)");
            System.out.println("2) Display longest sent message");
            System.out.println("3) Search for message by ID");
            System.out.println("4) Search messages by recipient");
            System.out.println("5) Delete message by ID");
            System.out.println("6) Exit");

            String option = input.nextLine();

            switch (option) {
                case "1":
                    System.out.println("All sent messages:");
                    for (Message m : sentMessages) {
                        System.out.println("Recipient: " + m.getRecipientNumber() + " | Message: " + m.getContent());
                    }
                    break;

                case "2":
                    if (sentMessages.isEmpty()) {
                        System.out.println("No sent messages.");
                        break;
                    }
                    Message longest = sentMessages.get(0);
                    for (Message m : sentMessages) {
                        if (m.getContent().length() > longest.getContent().length()) {
                            longest = m;
                        }
                    }
                    System.out.println("Longest sent message:");
                    System.out.println(longest.printMessage());
                    break;

                case "3":
                    System.out.print("Enter message ID to search: ");
                    int searchId;
                    try {
                        searchId = Integer.parseInt(input.nextLine());
                    } catch (NumberFormatException e) {
                        System.out.println("Invalid ID.");
                        break;
                    }
                    boolean found = false;
                    for (Message m : sentMessages) {
                        if (m.getId() == searchId) {
                            System.out.println("Message found:");
                            System.out.println(m.printMessage());
                            found = true;
                            break;
                        }
                    }
                    if (!found) {
                        System.out.println("Message ID not found.");
                    }
                    break;

                case "4":
                    System.out.print("Enter recipient number to search: ");
                    String searchRecipient = input.nextLine();
                    boolean foundRecipient = false;
                    for (Message m : sentMessages) {
                        if (m.getRecipientNumber().equals(searchRecipient)) {
                            System.out.println(m.printMessage());
                            foundRecipient = true;
                        }
                    }
                    if (!foundRecipient) {
                        System.out.println("No messages found for that recipient.");
                    }
                    break;

                case "5":
                    System.out.print("Enter message ID to delete: ");
                    int deleteId;
                    try {
                        deleteId = Integer.parseInt(input.nextLine());
                    } catch (NumberFormatException e) {
                        System.out.println("Invalid ID.");
                        break;
                    }
                    boolean deleted = false;
                    for (int idx = 0; idx < sentMessages.size(); idx++) {
                        if (sentMessages.get(idx).getId() == deleteId) {
                            sentMessages.remove(idx);
                            System.out.println("Message deleted.");
                            deleted = true;
                            break;
                        }
                    }
                    if (!deleted) {
                        System.out.println("Message ID not found.");
                    }
                    break;

                case "6":
                    System.out.println("Exiting application.");
                    input.close();
                    return;

                default:
                    System.out.println("Invalid option. Please select again.");
            }
        }
    }
}
